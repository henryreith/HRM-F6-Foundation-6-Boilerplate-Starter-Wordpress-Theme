<?php
/*
Navbar search form
==================

If you don't want a search form in your navbar, then delete the link to this PHP page from within the navbar in header.php.

Then you can insert the Search Widget into the sidebar.
*/
?>

<ul class="menu">
	<li><input type="search" placeholder="Search"></li>
	<li><button type="button" class="button">Search</button></li>
</ul>